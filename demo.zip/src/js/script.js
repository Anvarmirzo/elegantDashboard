document.addEventListener('DOMContentLoaded', function () {
  'use strict'
  @@include('check-webp.js')
  @@include('feather-init.js')
  @@include('_aside.js')
  @@include('_lang-switcher.js')
  @@include('_users-dropdown.js')
  @@include('_dark-mode.js')
  @@include('_checkbox.js')
  @@include('_chart-config.js')
});